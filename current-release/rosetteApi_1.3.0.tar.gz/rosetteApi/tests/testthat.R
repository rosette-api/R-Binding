library(testthat)
library(rosetteApi)

test_check("rosetteApi")
